<template>
  <transition name="fade" mode="out-in"><slot /></transition>
</template>

<script>
export default {
  //
}
</script>
